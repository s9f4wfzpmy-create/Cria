---
name: Artisan Curated Marketplace
colors:
  surface: '#fcf9f8'
  surface-dim: '#dcd9d9'
  surface-bright: '#fcf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f2'
  surface-container: '#f0edec'
  surface-container-high: '#ebe7e7'
  surface-container-highest: '#e5e2e1'
  on-surface: '#1c1b1b'
  on-surface-variant: '#5b4038'
  inverse-surface: '#313030'
  inverse-on-surface: '#f3f0ef'
  outline: '#8f7067'
  outline-variant: '#e4beb3'
  surface-tint: '#ae3200'
  primary: '#ae3200'
  on-primary: '#ffffff'
  primary-container: '#ff5a1f'
  on-primary-container: '#541400'
  inverse-primary: '#ffb59e'
  secondary: '#6000da'
  on-secondary: '#ffffff'
  secondary-container: '#7a2cff'
  on-secondary-container: '#ebdfff'
  tertiary: '#5d5f5f'
  on-tertiary: '#ffffff'
  tertiary-container: '#919292'
  on-tertiary-container: '#292b2c'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdbd0'
  primary-fixed-dim: '#ffb59e'
  on-primary-fixed: '#3a0b00'
  on-primary-fixed-variant: '#852400'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d1bcff'
  on-secondary-fixed: '#24005b'
  on-secondary-fixed-variant: '#5700c8'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c7'
  on-tertiary-fixed: '#1a1c1c'
  on-tertiary-fixed-variant: '#454747'
  background: '#fcf9f8'
  on-background: '#1c1b1b'
  surface-variant: '#e5e2e1'
typography:
  display-lg:
    fontFamily: Bebas Neue
    fontSize: 80px
    fontWeight: '400'
    lineHeight: 80px
    letterSpacing: 0.02em
  headline-lg:
    fontFamily: Bebas Neue
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 52px
    letterSpacing: 0.03em
  headline-lg-mobile:
    fontFamily: Bebas Neue
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: 0.03em
  headline-md:
    fontFamily: Bebas Neue
    fontSize: 32px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: 0.04em
  body-lg:
    fontFamily: Newsreader
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 32px
  body-md:
    fontFamily: Newsreader
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
  section-gap: 120px
---

## Brand & Style
The design system embodies a "Digital Museum" aesthetic—airy, sophisticated, and intentionally curated. It targets high-end artisans and discerning collectors who value craftsmanship over mass production. 

The visual language follows a **Refined Glassmorphism** style. It moves away from heavy, dark interfaces toward a luminous, breathing space. By utilizing high-contrast typography against a soft, premium canvas, the design system ensures that the artisan products remain the focal point. The "Liquid Glass" metaphor translates into light mode as frosted white surfaces that appear to float over the off-white background, creating a sense of physical depth and tactile luxury.

## Colors
The palette is rooted in a premium off-white (#F9F9F9) which serves as the "gallery wall." 

- **Primary (Artistic Orange):** Used for primary calls to action and critical highlights. In light mode, its glow is softened to a 15% opacity tint to avoid visual vibration.
- **Secondary (Electric Purple):** Used for secondary interactions, categories, and luxury tiering.
- **Neutral (Deep Charcoal):** Used for all primary text and structural borders to ensure high legibility and an editorial feel.
- **Liquid Glass Surface:** A semi-transparent white (#FFFFFF at 70-80% opacity) with a background blur effect.

## Typography
The typographic hierarchy relies on the tension between the tall, authoritative **Bebas Neue** and the literary, elegant **Newsreader**. 

Headlines should be treated as architectural elements—large, uppercase, and impactful. For long-form descriptions of artisanal works, Newsreader provides a warm, human touch that mimics premium editorial magazines. **Inter** is reserved for functional labels, navigation, and metadata to maintain a clean, systematic foundation. High-end spacing is achieved by increasing line-heights for body text and maintaining generous kerning for display type.

## Layout & Spacing
This design system utilizes a **Fixed Centric Grid** for desktop to mimic a curated gallery layout. 

A 12-column grid is standard, but content should frequently "breathe" by utilizing 2-column offsets for centered text blocks. Section gaps are intentionally large (120px+) to distinguish different artisanal collections and prevent visual clutter. Mobile layouts transition to a single column with 20px margins, but maintain the vertical rhythm by keeping the 8px baseline unit.

## Elevation & Depth
Depth is created through the **Liquid Glass** system, which uses three specific layers of light:

1.  **Base Layer:** The off-white (#F9F9F9) canvas.
2.  **Glass Panels:** White translucent backgrounds (#FFFFFF @ 70%) with a `24px` backdrop blur.
3.  **Luminous Borders:** A 1px solid stroke at the top and left edges (#FFFFFF @ 50%) and a darker 1px stroke at the bottom and right (#000000 @ 5%) to simulate light hitting a glass edge.

Shadows must be extremely soft: use a `0 20px 40px rgba(0,0,0,0.04)` for floating cards, ensuring they feel weightless rather than heavy.

## Shapes
The shape language is sophisticated and "liquid." We use **Level 2 (Rounded)** corners to soften the aggressive nature of the condensed headlines. 

- **Containers & Cards:** 1rem (16px) corner radius.
- **Buttons & Inputs:** 0.5rem (8px) corner radius to provide a slight structural contrast to larger panels.
- **Image Frames:** Always use the container radius to maintain a nested, "framed" appearance.

## Components
### Buttons
Primary buttons use a solid Artistic Orange fill with white text. Secondary buttons utilize the "Liquid Glass" style: a translucent white background with a thin charcoal border and Newsreader (Bold) text.

### Cards
Artisan cards feature no visible background until hovered. Upon hover, a Liquid Glass panel fades in behind the product image, creating a "lift" effect. 

### Input Fields
Fields are minimalist: a single 1px bottom border in Deep Charcoal. Upon focus, the field expands into a soft Liquid Glass pill with a subtle Artistic Orange glow (10% opacity).

### Chips & Tags
Used for material types (e.g., "Ceramics", "Leather"). These are styled with Inter (Label-sm) and a very light gray background (#EEE), using pill-shaped geometry to contrast with the more rectangular product cards.

### Lists
Lists in the marketplace are treated as "Exhibits." Each item is separated by a faint horizontal rule (#000 @ 5% opacity) with generous 32px padding to ensure each artisan's name has room to breathe.